#ifndef PLANEINFORMATION_H
#define PLANEINFORMATION_H
#include"flightGenerator.h"
PLANE_T* addAirPlane();
/* This function will print plane information from structure
 * input PLANE_T structure */
void printPlane(PLANE_T* input);
#endif